package cs455.overlay.node;

public interface Node {

}
